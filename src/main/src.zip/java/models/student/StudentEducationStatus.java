package models.student;

public enum StudentEducationStatus {
    STUDYING,
    GRADUATE,
    WITHDRAWN
}
