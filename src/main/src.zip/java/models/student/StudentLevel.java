package models.student;

public enum StudentLevel {
    UNDERGRADUATE,
    MASTERS_STUDENT,
    PHD_STUDENT
}
