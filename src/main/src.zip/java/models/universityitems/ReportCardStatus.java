package models.universityitems;

public enum ReportCardStatus {
    TAKEN,
    WITHDRAWN,
    FAILED,
    TEMPORARILY_SCORED,
    CREDITED,
}
