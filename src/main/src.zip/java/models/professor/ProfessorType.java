package models.professor;

public enum ProfessorType {
    NORMAL,
    EDUCATIONAL_ASSISTANT,
    DEAN_OF_THE_FACULTY
}
