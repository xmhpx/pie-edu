package models.professor;

public enum ProfessorLevel {
    ASSISTANT_PROFESSOR,
    ASSOCIATE_PROFESSOR,
    FULL_PROFESSOR
}
