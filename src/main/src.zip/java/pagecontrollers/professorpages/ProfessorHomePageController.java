package pagecontrollers.professorpages;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class ProfessorHomePageController extends ProfessorPageController {
    private static final Logger log = LogManager.getLogger(ProfessorHomePageController.class);

    public static final String fxmlFileName = "professorHomePage.fxml";

    @Override
    public void initialize(){
        super.initialize();
    }

}
